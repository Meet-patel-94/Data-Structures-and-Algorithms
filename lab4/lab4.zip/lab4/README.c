Give the Big-Theta complexity (as a function of n, the number of items in the list) of the operations: 

    ◦insert: 

    ◦delete: 

    ◦list_size: 



The answers are stated below:

insert -

big theta 1

delete -

big theta 1

list_size -

big theta n
