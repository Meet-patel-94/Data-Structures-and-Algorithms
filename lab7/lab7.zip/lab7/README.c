Hello TA: LUNA FENG

NAME: MEET PATEL
ID: 500509440
Section:01

My Lab is working perfectly. The code is compiling after typing the heap command and it works, when you input any random amount numbers. When entering any random 5 numbers the input command on terminal reads from descending to ascending order.

For example when you you take lets say 5 numbers: 10,20,30,40,50 

The reading input displays 10, 20, 30, 40 ,50
then the node is identified.

<node id="50">
	<node id="40">
		<node id="10"></node>

		<node id="30"></node>
	</node>

	<node id="20"></node>
        </node>

After node identification. The next print command reads from Descending order to Ascending order.

Descending Order
50
40
30
20
10

Ascending Order
10
20
30
40
50


Thats all folks.

Dear Luna it was a pleasure to have you has my TA hope to see you in future courses as a TA.


